
import java.io.IOException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class serv
 */
@WebServlet("/serv")
public class serv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String sal=request.getParameter("salary");
		 String oth=request.getParameter("other");
		 String home=request.getParameter("home"); 
		 String rent=request.getParameter("rent"); 
		 String otherhome=request.getParameter("other home"); 
		 String tt=request.getParameter("tt"); 
		 String ttamt=request.getParameter("transport");
		 String eduamt=request.getParameter("edu"); 
		 String g=request.getParameter("g"); 
		 String famt=request.getParameter("amt"); 
		 String limit=request.getParameter("limit");
		 try{
		 int sal1=Integer.parseInt(sal);
		 int oth1=Integer.parseInt(oth);
		 int rent1=Integer.parseInt(rent);
		 int otherhome1=Integer.parseInt(otherhome);
		 int ttamt1=Integer.parseInt(ttamt);
		 int eduamt1=Integer.parseInt(eduamt);
		 int famt1=Integer.parseInt(famt);
		 int limit1=Integer.parseInt(limit);
		 int total=sal1+oth1;
		 if(home.equals("Own"))
		 {
			 rent1=0;
		 }else if(home.equals("Rented")){
			 otherhome1=0;
		 }
		 if(tt.equals("w")){
			 ttamt1=ttamt1*4;
		 }
		 int expenses=rent1+otherhome1+ttamt1+eduamt1+famt1;
		 int savings=total-expenses;
		 int lim=(limit1/100)*total;
		 response.getWriter().println("<title>Expenses Tracker</title>");
		 response.getWriter().println("<header><b>Your Expenses Tracked</b></header>"+"<style> header {height:80px;background-color:#4CAF50;padding:3px;text-align: center;font-size: 45px; color: white;font-family:Calibri;}b {margin-top:15%;}</style>");
		 response.getWriter().println("<marquee behavior='slide' direction='right'><img src='giphy1.gif' width='500' height='300'/></marquee>");
		 response.getWriter().println("<div><h1> You Spent Rs. "+expenses+" this month.</h1>");
		 response.getWriter().println("<h1>Your Savings are :  "+"Rs. "+savings+"</h1>"+"<style>div {  position: absolute;top:0;bottom:0;left:0;right:0;margin:auto;width:800px;height:200px;border: 8px solid #4CAF50;text-align:center;}h1 {color:#009999;}</style>");
		
		 if(savings<lim){
			 response.getWriter().println("<h1><p>"+"\"Save Money, Money will save YOU.\""+"</p></h1>"+"<style>p {color:#009999;}</style>");
			 
		 }else{
			 response.getWriter().println("<h1>Congrats ! You Reached your Goal..!!</h1></div>"+"<style>h2 {color:#009999;}</style>");
		 }
		 }
		 catch(NumberFormatException e){
			 response.getWriter().println("<h1 id='invalid' value='invalid'>Invalid Data.</h1>"+"<style>h1 {position:absolute;margin-left:40%;margin-top:20%;font-size:50px;}</style>");
		 }
		 
	}

}
