

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class hello
 */
@WebServlet("/hello")
public class hello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String username=request.getParameter("uname");
		 String pswd=request.getParameter("l-pswd");
		 
		 //..
	
			//..
			
		//Database credentials
		 final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	        final String DB_URL = "jdbc:mysql://localhost/signup";
	        // ***********************************************************************
	        // Database credentials
	        final String USER = "root";
	        final String PASS = "root";
	        Connection conn = null;
	        Statement stmt = null;
	        //String username="jyo";
	       // String password="jyo";
	        try {
	            // Register JDBC driver
	            Class.forName(JDBC_DRIVER);
	            //System.out.println("Connecting to a selected database...");
	            conn = (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
	            //System.out.println("Connected database successfully...");
	 
	            // create a Statement object ()
	            //System.out.println("Inserting records into the table...");
	            stmt = (Statement) conn.createStatement();
	            String queryString = "SELECT username, password FROM sign where username=? and password=?";
	            PreparedStatement ps = (PreparedStatement) conn.prepareStatement(queryString);
	            ps = (PreparedStatement) conn.prepareStatement(queryString);
	            ps.setString(1,username);
	            ps.setString(2,pswd);
	            ResultSet results = ps.executeQuery();
	            if (results.next()) {
	                response.sendRedirect("home.jsp");  
	            }else{
	                //JOptionPane.showMessageDialog(null, "Please Check Username and Password ");
	            	JOptionPane jop = new JOptionPane();
	            	jop.setMessageType(JOptionPane.PLAIN_MESSAGE);
	            	jop.setMessage("Please Check Username and Password");
	            	final JDialog dialog = jop.createDialog(null, "Message");

	            	// Set a 2 second timer
	            	new Thread(new Runnable() {
	            		@Override
	            		public void run() {
	            			try {
	            				Thread.sleep(1000);
	            			} catch (Exception e) {
	            			}
	            			dialog.dispose();
	            		}

	            	}).start();

	            	dialog.setVisible(true);
	            		
	                 response.sendRedirect("login.jsp");
	            } 
	            
	 
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
    }

	
}
